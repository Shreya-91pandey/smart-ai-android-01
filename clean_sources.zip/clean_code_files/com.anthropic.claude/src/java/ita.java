public interface ita
{
}
