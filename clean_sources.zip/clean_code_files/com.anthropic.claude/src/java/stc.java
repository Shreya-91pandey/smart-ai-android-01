public interface stc
{
}
