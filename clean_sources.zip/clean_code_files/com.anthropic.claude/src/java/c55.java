public interface c55
{
}
