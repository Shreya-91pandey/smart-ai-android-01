public interface hm7
{
}
