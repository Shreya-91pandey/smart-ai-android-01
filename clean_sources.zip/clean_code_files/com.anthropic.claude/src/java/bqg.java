public interface bqg
{
}
