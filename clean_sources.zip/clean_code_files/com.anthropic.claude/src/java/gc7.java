public interface gc7
{
}
